require([
    'DavidVerholen_Teaser/js/teasergroup/edit/post-wrapper'
]);
