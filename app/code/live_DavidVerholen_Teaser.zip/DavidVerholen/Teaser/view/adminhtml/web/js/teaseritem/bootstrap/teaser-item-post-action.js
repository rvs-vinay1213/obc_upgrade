require([
    'DavidVerholen_Teaser/js/teaseritem/edit/post-wrapper'
]);
