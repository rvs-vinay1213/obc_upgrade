<?php

namespace DavidVerholen\Teaser\Block\Adminhtml\TeaserGroup\Edit\Tab;

use Magento\Ui\Component\Listing;

class TeaserItemListing extends Listing
{

}
