<?php

namespace DavidVerholen\Teaser\Block\Widget;

use DavidVerholen\Teaser\Block\TeaserGroup as TeaserGroupBlock;
use Magento\Widget\Block\BlockInterface;

class TeaserGroup extends TeaserGroupBlock implements BlockInterface
{
}
