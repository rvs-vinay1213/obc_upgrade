<?php
/**
* @copyright Copyright (c) 2016 www.magebuzz.com
*/

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Magebuzz_Socialshare',
    __DIR__
);