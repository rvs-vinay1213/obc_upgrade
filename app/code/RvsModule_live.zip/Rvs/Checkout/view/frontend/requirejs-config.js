var config = {
    map: {
        '*': {
      		'Magento_Checkout/template/payment-methods/list.html':
          	'Rvs_Checkout/template/payment-methods/list.html',
          	'Magento_Tax/template/checkout/summary/subtotal.html':
          	'Rvs_Checkout/template/checkout/summary/subtotal.html',
          	shippingOnTime:'Rvs_Checkout/js/shippingontime'
        }
  	}
};