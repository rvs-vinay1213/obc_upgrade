var config = {
    map: {
        '*': {
            'Amasty_Checkout/js/action/update-delivery': 'Rvs_HideShippingMethod/js/action/update-delivery',
        }
    }
};