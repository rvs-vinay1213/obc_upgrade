var config = {
	map: {
        '*': {
            owen: 'js/owen'
        }
    }
}
